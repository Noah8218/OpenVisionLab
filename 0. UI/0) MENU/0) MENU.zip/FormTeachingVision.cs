﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;
using System.Threading;
using System.Diagnostics;
using System.IO;
using System.Collections;
using System.Net;
using System.Net.Sockets;

using OpenCvSharp;
using OpenCvSharp.UserInterface;
using OpenCvSharp.Blob;

using MetroFramework;
using MetroFramework.Controls;
using MetroFramework.Forms;

using ImageGlass;
using System.Collections.Concurrent;
using Cognex.VisionPro.ImageFile;
using Cognex.VisionPro.ImageProcessing;
using Cognex.VisionPro.PMAlign;
using Cognex.VisionPro.Caliper;
using Cognex.VisionPro;

#if MATROX
using Matrox.MatroxImagingLibrary; 
#endif

#if DATAMATRIXNET
using DataMatrix.net;
#endif

namespace IntelligentFactory
{
    public partial class FormTeachingVision : MetroForm
    {
        private IGlobal Global = IGlobal.Instance;

        private CCogTool_PMAlign m_cogTool_PMAlign = null;
        private CCogTool_FindLine m_cogTool_FindLineL = null;
        private CCogTool_FindLine m_cogTool_FindLineR = null;
        private CCogTool_ViDi_OCR m_cogTool_ViDi_OCR = null;

        private string m_strSelectFindLineDir = "LEFT";

#if HIKVISION
        public CCameraHikVision CAMERA { get; set; } = null; 
#endif


        //private MIL_ID ImageSource = new MIL_ID();
        private Mat    ImageSource = new Mat();
        private CogImage8Grey m_ImageSource = new CogImage8Grey();

#if MATROX
        private MIL_ID ImageMSource = MIL.M_NULL;
#endif
        private Bitmap ImageDisplay = new Bitmap(1024, 768);

        private float m_fScaleFactorX = 1.0F;
        private float m_fScaleFactorY = 1.0F;

        private const int DGV_NO = 0;
        private const int DGV_NAME = 1;
        private const int DGV_STATUS = 2;

        private List<string> ListPreImageProcess = new List<string>();

        public float m_fImageScale { get; set; } = 1;

        private string m_strSelectedTab = "UPPER LIFT";

        private Dictionary<string, List<CSignal>> Inputs_Reference = new Dictionary<string, List<CSignal>>();
        private Dictionary<string, List<CSignal>> Outputs_Reference = new Dictionary<string, List<CSignal>>();

        private List<string> m_strOCRRead = new List<string>();
        #region Event Register        
        public EventHandler<EventArgs> EventUpdateUi;
#endregion

        public FormTeachingVision()
        {
            InitializeComponent();
        }

        private void FormTeachingVision_Load(object sender, EventArgs e)
        {
            //if (DesignMode) return; 

            EventUpdateUi += OnUpdateUi;

            if (EventUpdateUi != null)
            {
                EventUpdateUi(null, null);
            }

            Global.System.Recipe.EventChagedRecipe += OnChangedRecipe;

            m_cogTool_PMAlign = CVisionTools.PMALIGN_FRONT;
            m_cogTool_FindLineL = CVisionTools.FINDLINE_FRONT_LEFT;
            m_cogTool_FindLineR = CVisionTools.FINDLINE_FRONT_RIGHT;
            m_cogTool_ViDi_OCR = CVisionTools.OCR;

            cbCamera.SelectedIndex = 0;

            InitUI();
            InitControl();
            InitProperty();
            InitEventCamera();
        }
        
        private void OnGrabEnd(object sender, GrabEventArgs e)
        {
            if (this.InvokeRequired)
            {
                try
                {
                    this.Invoke(new MethodInvoker(() =>
                    {
                        OnGrabEnd(sender, e);
                    }));
                }
                catch (Exception ex)
                {
                    CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
                }
            }
            else
            {
                try
                {
                    int nW = Global.iDevice.CAMERA_FRONT.m_stFrameInfo.nWidth;
                    int nH = Global.iDevice.CAMERA_FRONT.m_stFrameInfo.nHeight;
                    string strIndex = cbCamera.Text;

                    switch (strIndex)
                    {
                    case "FRONT":
                        {
                            cogDisplay_Source.Image = Common.Convert8BitRawImageToCognexImage(e.ImagePtr, nW, nH);
                            cogDisplay_Source.Fit();
                            m_ImageSource = (CogImage8Grey)cogDisplay_Source.Image;
                        }
                        break;
                    case "BACK":
                        {
                            cogDisplay_Source.Image = Common.Convert8BitRawImageToCognexImage(e.ImagePtr, nW, nH);
                            cogDisplay_Source.Fit();
                            m_ImageSource = (CogImage8Grey)cogDisplay_Source.Image;
                        }
                        break;
                    case "OCR":
                        {
                            cogDisplay_Source.Image = Common.Convert8BitRawImageToCognexImage(e.ImagePtr, nW, nH);
                            cogDisplay_Source.Fit();
                            m_ImageSource = (CogImage8Grey)cogDisplay_Source.Image;
                        }
                        break;
                    }

                    GC.Collect();
                }
                catch (Exception ex)
                {
                    CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
                }
            }
        }
        public void InitEventCamera()
        {
            Global.iDevice.CAMERA_FRONT.EventGrabEnd += OnGrabEnd;
            Global.iDevice.CAMERA_BACK.EventGrabEnd += OnGrabEnd;
            Global.iDevice.CAMERA_OCR.EventGrabEnd += OnGrabEnd;
        }
        private void InitControl()
        {
            try
            {

            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.ABNORMAL, "[FAILED] {0}==>{1}   Ex ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        private void FormTeachingMotion_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.ABNORMAL, "[FAILED] {0}==>{1}   Ex ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        private bool InitUI()
        {
            try
            {
                if(m_cogTool_PMAlign.TrainedPatternImage != null)
                {
                    cogDisplay_Pattern.Image = m_cogTool_PMAlign.TrainedPatternImage;
                    cogDisplay_Pattern.Fit();
                }

                this.Invalidate();

                CVisionTools.Init();
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        private bool InitProperty()
        {
            try
            {
                Global.iData.PropertyVisionInsp.LoadConfig(Global.System.Recipe.Name);
                Global.iData.PropertyBufferPitch.LoadConfig(Global.System.Recipe.Name);

                propertyGrid_Spec.SelectedObject = Global.iData.PropertyVisionInsp;

                this.Invalidate();
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        private void ImageBox_MouseWheelEvent(object sender, MouseEventArgs e)
        {
            try
            {
                if (!(sender is ImageBoxEx)) return;
                ImageBoxEx ib = (sender as ImageBoxEx);

                if (e.Delta > 0) ib.ZoomIn();
                else ib.ZoomOut();
            }
            catch (Exception ex)
            {

            }
        }

        private void ImageBox_MouseDoubleClickEvent(object sender, MouseEventArgs e)
        {
            try
            {
                if (!(sender is ImageBoxEx)) return;
                ImageBoxEx ib = (sender as ImageBoxEx);

                FormImageEditView FrmImageView = new FormImageEditView((Bitmap)ib.Image);
                if (FrmImageView.ShowDialog() == DialogResult.OK)
                {
                    //SetImageData("SOURCE", FrmImageView.ImageProcess);
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void OnUpdateUi(object sender, EventArgs e)
        {
            if (this.InvokeRequired)
            {
                try
                {
                    this.Invoke(new MethodInvoker(() =>
                    {
                        OnUpdateUi(sender, e);
                    }));
                }
                catch (Exception ex)
                {
                    CLogger.Add(LOG.ABNORMAL, "[FAILED] {0}==>{1}   Ex ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
                }
            }
            else
            {

                CLogger.Add(LOG.NORMAL, "[OK] {0}==>{1}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name);
            }
        }

        private void OnChangedRecipe(object sender, EventArgs e)
        {
            if (this.InvokeRequired)
            {
                try
                {
                    this.Invoke(new MethodInvoker(() =>
                    {
                        OnChangedRecipe(sender, e);
                    }));
                }
                catch (Exception ex)
                {
                    CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
                }
            }
            else
            {
                try
                {
                    InitProperty();
                    InitUI();
                }
                catch (Exception ex)
                {
                    CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
                }
            }
        }

        #region IMAGEBOX WHEEL

        private void MouseWheelEventSource(object sender, MouseEventArgs e)
        {
            if ((e.Delta / 120) > 0) (sender as ImageBoxEx).ZoomIn();
            else (sender as ImageBoxEx).ZoomOut();
        }

        private void MouseWheelEventProcess(object sender, MouseEventArgs e)
        {
            if ((e.Delta / 120) > 0)
            {
                // up
                if (m_fImageScale > 1)
                    m_fImageScale--;

                ZoomInImageProcess();
            }
            else
            {
                // down
                m_fImageScale++;

                ZoomOutImageProcess();
            }
        }

        private void ZoomInImageProcess()
        {
        }

        private void ZoomOutImageProcess()
        {
        }

#endregion
        private bool InitFilter()
        {
            try
            {
              
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }
        public CThreadStatus ThreadStatusLive { get; set; } = new CThreadStatus();

        private void StartThreadLive()
        {

            if (ThreadStatusLive.IsExit())
            {
                Thread t = new Thread(new ParameterizedThreadStart(ThreadLive));
                t.Start(ThreadStatusLive);
            }
        }

        public void StopThreadLive()
        {
            if (!ThreadStatusLive.IsExit())
            {
                ThreadStatusLive.Stop(100);
            }

            ThreadStatusLive.End();
        }

        private void ThreadLive(object ob)
        {
            CThreadStatus ThreadStatus = (CThreadStatus)ob;

            ThreadStatus.Start("Start the Live");

            if(CAMERA == null)
            {
                ThreadStatus.End();
                return;
            }

            try
            {
                while (!ThreadStatus.IsExit())
                {
                    Thread.Sleep(50);
                }

                ThreadStatus.End();
                return;
            }
            catch (Exception ex)
            {
                ThreadStatus.End();
            }
        }
        private void timerStatus_Tick(object sender, EventArgs e)
        {
            try
            {
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.ABNORMAL, "[FAILED] {0}==>{1}   Ex ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        private void OnKeyPress(object sender, KeyPressEventArgs e)
        {
            CUtil.InputOnlyNumber(sender, e, true, true);
        }


        private void cbCamera_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string strIndex = cbCamera.Text;

                switch(strIndex)
                {
                case "FRONT":
                    {
                        m_cogTool_PMAlign = CVisionTools.PMALIGN_FRONT;
                        m_cogTool_FindLineL = CVisionTools.FINDLINE_FRONT_LEFT;
                        m_cogTool_FindLineR = CVisionTools.FINDLINE_FRONT_RIGHT;
                        CAMERA = Global.iDevice.CAMERA_FRONT;
                    }
                    break;
                case "BACK":
                    {
                        m_cogTool_PMAlign = CVisionTools.PMALIGN_BACK;
                        m_cogTool_FindLineL = CVisionTools.FINDLINE_BACK_LEFT;
                        m_cogTool_FindLineR = CVisionTools.FINDLINE_BACK_RIGHT;
                        CAMERA = Global.iDevice.CAMERA_BACK;
                    }
                    break;
                case "OCR":
                    {
                        CAMERA = Global.iDevice.CAMERA_OCR;
                    }
                    break;
                }

                cogDisplay_Source.InteractiveGraphics.Clear();
                if(cogDisplay_Pattern != null)
                {
                    cogDisplay_Pattern.Image = m_cogTool_PMAlign.TrainedPatternImage;
                    cogDisplay_Pattern.Fit();
                }
                
                CLogger.Add(LOG.NORMAL, "[OK] {0}==>{1}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name);
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        private void btnCameraOperator_Click(object sender, EventArgs e)
        {
            pnCameraOperator.Visible = !pnCameraOperator.Visible;
        }


        private void trbThreshold_Scroll(object sender, ScrollEventArgs e)
        {
            try
            {
                if (CUtil.IsImageEmpty(ImageSource)) return;

                int nThreshold = trbThreshold.Value;
                lbThreshold.Text = nThreshold.ToString();

                using(Mat imageSrc = ImageSource.Clone())
                {

                }
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        private void btnMeasureMean_Click(object sender, EventArgs e)
        {
            try
            {
                FormImageEditView FrmImageEdit = new FormImageEditView(ImageSource);
                if (FrmImageEdit.ShowDialog() == DialogResult.OK)
                {
                    Rect rtROI = FrmImageEdit.SelectedRegion;

                    if (CUtil.IsImageEmpty(ImageSource)) return;

                    using (Mat imageSrc = ImageSource.Clone())
                    using (Mat imageSub = imageSrc.SubMat(rtROI))
                    {
                        CUtil.SetImageChannel1(imageSub);
                        lbMean.Text = Cv2.Mean(imageSub).Val0.ToString("F2");
                    }
                }                
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        private void btnSetRoi_Click(object sender, EventArgs e)
        {
            try
            {
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        private void OnClickCameraOperation(object sender, EventArgs e)
        {
            try
            {
                

                if (!(sender is MetroButton)) return;

                string strIndex = (sender as MetroButton).Text;

                switch (strIndex)
                {
                case "SETTING":
                    break;
                case "GRAB":
                    if (CAMERA == null) return;
                    CAMERA.Grab();
                    break;
                case "LIVE":
                    if (CAMERA == null) return;
                    CAMERA.Live(true);
                    (sender as MetroButton).Text = "LIVE STOP";
                    break;
                case "LIVE STOP":
                    if (CAMERA == null) return;
                    (sender as MetroButton).Text = "LIVE";
                    CAMERA.Live(false);
                    break;
                case "CROSS":
                    CAMERA.ViewModeCross = !CAMERA.ViewModeCross;
                    break;
                case "IMAGE LOAD":
                    try
                    {
                        cogDisplay_Source.InteractiveGraphics.Clear();

                        OpenFileDialog ofd = new OpenFileDialog();
                        ofd.Title = "Image Load";
                        ofd.Filter = "Image File (*.png, *.jpg, *.gif, *.bmp) | *.png; *.jpg; *.gif; *.bmp; | 모든 파일 (*.*) | *.*";

                        if (ofd.ShowDialog() == DialogResult.OK)
                        {
                            string strFilePath = ofd.FileName;

                            //cogDisplay1.InteractiveGraphics.Add( ( ICogGraphicInteractive ) CurrentTool.Pattern.TrainRegion
                            if (File.Exists(strFilePath))
                            {
                                CogImageFile ImageFile1 = new CogImageFile();

                                ImageFile1.Open(strFilePath, CogImageFileModeConstants.Read);

                                if (ImageFile1.Count > 0)
                                {
                                    ICogImage image = ImageFile1[0];
                                    CogImageConvertTool cogImageConverter = new CogImageConvertTool();
                                    cogImageConverter.InputImage = image;
                                    cogImageConverter.Run();

                                    m_ImageSource = (CogImage8Grey)cogImageConverter.OutputImage;
                                    cogDisplay_Source.Image = m_ImageSource;
                                    cogDisplay_Source.Fit(true);
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    //string strImagePath = CUtil.LoadImage();
                    //ImageSource = Cv2.ImRead(strImagePath);
                    break;
                case "IMAGE SAVE":
                    if (!CUtil.IsImageEmpty(ImageSource))
                    {
                        string strImagePath = CUtil.SaveImage();
                        Cv2.ImWrite(strImagePath, ImageSource);
                    }
                    break;
                case "TRIG (SW)":
                    //CAMERA.SoftwareTrigger();
                    break;
                case "TRIG (HW)":
                    //CAMERA.HardwareTrigger();
                    break;
                case "보기 (전체)":
                    break;
                }

                CLogger.Add(LOG.NORMAL, "[OK] {0}==>{1}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name);
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        private void OnClickMatchingProperty(object sender, EventArgs e)
        {
            try
            {
                propertyGrid_Tool.SelectedObject = CVisionTools.PMALIGN_FRONT.Tool.RunParams;

            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        private void btnSaveVisionParam_Click(object sender, EventArgs e)
        {
            try
            {
                CVisionTools.Save();

                Global.iData.PropertyVisionInsp.SaveConfig(Global.System.Recipe.Name);

                // 노출 시간
                float dblExposure = 0.0f;
                dblExposure = (float)Global.iData.PropertyVisionInsp.FRONT_CAMERA_EXPOSURE;
                Global.iDevice.CAMERA_FRONT.SetExposure(dblExposure);
                Global.iDevice.CAMERA_FRONT.SetGain(16);

                dblExposure = (float)Global.iData.PropertyVisionInsp.BACK_CAMERA_EXPOSURE;
                Global.iDevice.CAMERA_BACK.SetExposure(dblExposure);
                Global.iDevice.CAMERA_BACK.SetGain(16);

                dblExposure = (float)Global.iData.PropertyVisionInsp.BOTTOM_CAMERA_EXPOSURE;
                Global.iDevice.CAMERA_OCR.SetExposure(dblExposure);
                Global.iDevice.CAMERA_OCR.SetGain(16);

                CUtil.ShowMessageBox("RECIPE", "저장 완료", FormMessageBox.MESSAGEBOX_TYPE.CANCEL);
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        private void OnClickPatternRun(object sender, EventArgs e)
        {
            try
            {
                m_cogTool_PMAlign.Run(m_ImageSource);

                CogPMAlignResult result = m_cogTool_PMAlign.Result;
                if (result != null)
                {
                    cogDisplay_Source.InteractiveGraphics.Clear();
                    CogRectangleAffine cogROI = (CogRectangleAffine)m_cogTool_PMAlign.Tool.SearchRegion;
                    cogDisplay_Source.StaticGraphics.Add((ICogGraphicInteractive)cogROI, "ROI");
                    cogDisplay_Source.InteractiveGraphics.Add(result.CreateResultGraphics(CogPMAlignResultGraphicConstants.Origin), "main", false);
                    cogDisplay_Source.InteractiveGraphics.Add(result.CreateResultGraphics(CogPMAlignResultGraphicConstants.TipText), "main", false);
                    cogDisplay_Source.InteractiveGraphics.Add(result.CreateResultGraphics(CogPMAlignResultGraphicConstants.All), "main", false);
                }
                else
                {
                    CUtil.ShowMessageBox("FAIL", "패턴을 찾을 수 없습니다.");
                }
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        private void btnManualInspection_Click(object sender, EventArgs e)
        {
            try
            {
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }


        private void ibSource_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                FormImageEditView FrmImageEdit = new FormImageEditView((Bitmap)(sender as ImageBoxEx).Image, "");
                FrmImageEdit.ShowDialog();
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        private void btnPatternTrainRegion_Click(object sender, EventArgs e)
        {
            try
            {
                cogDisplay_Source.InteractiveGraphics.Clear();

                CogRectangleAffine cogROI = (CogRectangleAffine)m_cogTool_PMAlign.Tool.Pattern.TrainRegion;
                cogDisplay_Source.InteractiveGraphics.Add((ICogGraphicInteractive)cogROI, "main", false);
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        private void btnPatternTrain_Click(object sender, EventArgs e)
        {
            try
            {
                m_cogTool_PMAlign.Train(m_ImageSource, out ICogImage imgPattern);
                cogDisplay_Pattern.Image = imgPattern;
                cogDisplay_Pattern.Fit(true);
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        private void btnOpenEditTool_Click(object sender, EventArgs e)
        {
            try
            {
                FormCognex_PMALIGN tool = new FormCognex_PMALIGN();
                //CogPMAlignTool Ptn = new CogPMAlignTool();
                //Ptn.InputImage = m_ImageSource;
                tool.SetInfo(m_cogTool_PMAlign.Tool);
                tool.ShowDialog();

                // OLD
                //CogPMAlignEditV2 cogEidt_PMAlign = new CogPMAlignEditV2();
                //cogEidt_PMAlign.Subject = CVisionTools.PMALIGN_FRONT.Tool;
                //cogEidt_PMAlign.Show();
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        private void btnPatternSearchRegion_Click(object sender, EventArgs e)
        {
            try
            {
                cogDisplay_Source.InteractiveGraphics.Clear();

                if ((CogRectangleAffine)m_cogTool_PMAlign.Tool.SearchRegion == null)
                {
                    CogRectangleAffine cogRoiNew = new CogRectangleAffine();
                    cogRoiNew.FitToImage(m_ImageSource, 1.0D, 1.0D);
                    cogRoiNew.GraphicDOFEnable = CogRectangleAffineDOFConstants.All; 
                    cogRoiNew.Interactive = true; 
                    cogRoiNew.Color = CogColorConstants.Blue;
                    m_cogTool_PMAlign.Tool.SearchRegion = cogRoiNew;                    
                }
                string strIndex = cbCamera.Text;
                CogRectangleAffine cogROI = new CogRectangleAffine();
                if (strIndex == "FRONT" || strIndex == "BACK")
                {
                    cogROI = (CogRectangleAffine)m_cogTool_PMAlign.Tool.SearchRegion;
                    cogDisplay_Source.InteractiveGraphics.Add((ICogGraphicInteractive)cogROI, "main", false);
                }
                else
                {
                    cogROI.CenterX = m_ImageSource.Width / 2;
                    cogROI.CenterY = m_ImageSource.Height / 2;
                    cogROI.SideXLength = m_ImageSource.Width;
                    cogROI.SideYLength = m_ImageSource.Height;
                }
                

                // 선택영역을 속성창에 입력
                Rectangle rect = new Rectangle();
                rect.X = (int)(cogROI.CenterX - (cogROI.SideXLength / 2));
                rect.Y = (int)(cogROI.CenterY - (cogROI.SideYLength / 2));
                rect.Width = (int)(cogROI.SideXLength);
                rect.Height = (int)(cogROI.SideYLength);

                
                switch (strIndex)
                {
                case "FRONT": Global.iData.PropertyVisionInsp.FRONT_ROI = rect; break;
                case "BACK":  Global.iData.PropertyVisionInsp.BACK_ROI = rect; break;
                case "OCR":   Global.iData.PropertyVisionInsp.BOTTOM_ROI = rect; break;
                default:
                    break;
                }
                
                propertyGrid_Spec.Refresh();
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        
        private void btnFindLineLeft_Click(object sender, EventArgs e)
        {
            try
            {
                m_strSelectFindLineDir = "LEFT";

                cogDisplay_Source.InteractiveGraphics.Clear();
                cogDisplay_Source.StaticGraphics.Clear();

                CogLineSegment cogSegment;
                CogGraphicCollection cogRegions;
                ICogRecord cogRecord;

                CogFindLineTool cogFindLineTool = m_cogTool_FindLineL.Tool;
                propertyGrid_Tool.SelectedObject = m_cogTool_FindLineL.Tool.RunParams;
                cogFindLineTool.InputImage = m_ImageSource;
                cogFindLineTool.CurrentRecordEnable = CogFindLineCurrentRecordConstants.All;

                cogRecord = cogFindLineTool.CreateCurrentRecord();
                cogSegment = (CogLineSegment)cogRecord.SubRecords["InputImage"].SubRecords["ExpectedShapeSegment"].Content;
                cogRegions = (CogGraphicCollection)cogRecord.SubRecords["InputImage"].SubRecords["CaliperRegions"].Content;

                cogDisplay_Source.InteractiveGraphics.Add(cogSegment, "ExpectedShapeSegment", false);
                if (cogRegions == null)
                {
                    return;
                }
                foreach (ICogGraphic g in cogRegions)
                {
                    cogDisplay_Source.InteractiveGraphics.Add((ICogGraphicInteractive)g, "CaliperRegions", false);
                }
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        private void btnFindLineRight_Click(object sender, EventArgs e)
        {
            try
            {
                m_strSelectFindLineDir = "RIGHT";

                cogDisplay_Source.InteractiveGraphics.Clear();
                cogDisplay_Source.StaticGraphics.Clear();

                CogLineSegment cogSegment;
                CogGraphicCollection cogRegions;
                ICogRecord cogRecord;

                CogFindLineTool cogFindLineTool = m_cogTool_FindLineR.Tool;
                propertyGrid_Tool.SelectedObject = m_cogTool_FindLineR.Tool.RunParams;
                cogFindLineTool.InputImage = m_ImageSource;
                cogFindLineTool.CurrentRecordEnable = CogFindLineCurrentRecordConstants.All;

                cogRecord = cogFindLineTool.CreateCurrentRecord();
                cogSegment = (CogLineSegment)cogRecord.SubRecords["InputImage"].SubRecords["ExpectedShapeSegment"].Content;
                cogRegions = (CogGraphicCollection)cogRecord.SubRecords["InputImage"].SubRecords["CaliperRegions"].Content;

                cogDisplay_Source.InteractiveGraphics.Add(cogSegment, "ExpectedShapeSegment", false);
                if (cogRegions == null)
                {
                    
                    return;
                }   
                foreach (ICogGraphic g in cogRegions)
                {
                    cogDisplay_Source.InteractiveGraphics.Add((ICogGraphicInteractive)g, "CaliperRegions", false);
                }
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        private void propertyGrid_Tool_PropertyValueChanged(object s, PropertyValueChangedEventArgs e)
        {
            try
            {
                if(propertyGrid_Tool.SelectedObject is Cognex.VisionPro.Caliper.CogFindLine)
                {
                    if(m_strSelectFindLineDir == "LEFT")
                    {
                        btnFindLineLeft_Click(this, new EventArgs());
                    }
                    else
                    {
                        btnFindLineRight_Click(this, new EventArgs());
                    }
                }
                else if (propertyGrid_Tool.SelectedObject is Cognex.VisionPro.PMAlign.CogPMAlignTool)
                {

                }
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        private void btnRunFindLineLeft_Click(object sender, EventArgs e)
        {
            try
            {
                cogDisplay_Source.InteractiveGraphics.Clear();
                cogDisplay_Source.StaticGraphics.Clear();

                CogFindLineResults result;
                CVisionTools.RunFindLineDraw(cogDisplay_Source, m_cogTool_FindLineL, out result);
                
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        private void btnRunFindLineRight_Click(object sender, EventArgs e)
        {
            try
            {
                cogDisplay_Source.InteractiveGraphics.Clear();
                cogDisplay_Source.StaticGraphics.Clear();

                CogFindLineResults result;
                CVisionTools.RunFindLineDraw(cogDisplay_Source, m_cogTool_FindLineR, out result);
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        private void btnInspectionAll_Click(object sender, EventArgs e)
        {
            try
            {
                // 
                cogDisplay_Source.InteractiveGraphics.Clear();
                cogDisplay_Source.StaticGraphics.Clear();

                // 작업영역 설정
                if ((CogRectangleAffine)m_cogTool_PMAlign.Tool.SearchRegion == null)
                {
                    CogRectangleAffine cogRoiNew = new CogRectangleAffine();
                    cogRoiNew.FitToImage(m_ImageSource, 1.0D, 1.0D); // W:2048 H:2448
                    cogRoiNew.GraphicDOFEnable = CogRectangleAffineDOFConstants.All;
                    cogRoiNew.Interactive = true;
                    cogRoiNew.Color = CogColorConstants.Blue;
                    m_cogTool_PMAlign.Tool.SearchRegion = cogRoiNew;
                }
                //m_cogTool_PMAlign.Tool.SearchRegion.
                // 
                int START_TIME = Environment.TickCount;
                double dblLeft, dblRight;
                double dblX, dblY, dblAngle, dblScore;
                CVisionTools.RunPointToLine(cogDisplay_Source, m_cogTool_PMAlign, m_cogTool_FindLineL, m_cogTool_FindLineR, out dblLeft, out dblRight);
                m_cogTool_PMAlign.GetResult(out dblX, out dblY, out dblAngle, out dblScore);
                lbResultPatternAngle.Text = dblAngle.ToString("F2"); // 각도
                lbResultPatternExist.Text = $"DETECTED SCORE : {(dblScore * 100).ToString("F2")}%"; // 정확도
                lbResultLeftLineToPatternDist.Text = dblLeft.ToString("F2");
                lbResultRightLineToPatternDist.Text = dblRight.ToString("F2");

                int TACK_TIME = Environment.TickCount - START_TIME;
                lbTackTimems.Text = TACK_TIME.ToString() + "ms";
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        private void btnLoadConfig_PMAlign_Click(object sender, EventArgs e)
        {
            try
            {
                string strPath = CUtil.LoadPath();

                if(strPath != "")
                {
                    m_cogTool_PMAlign.LoadConfig_Manual(strPath);
                }
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        private void btnLoadConfig_FindLineL_Click(object sender, EventArgs e)
        {
            try
            {
                string strPath = CUtil.LoadPath();

                if (strPath != "")
                {
                    m_cogTool_FindLineL.LoadConfig_Manual(strPath);
                }
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        private void btnLoadConfig_FindLineR_Click(object sender, EventArgs e)
        {
            try
            {                
                string strPath = CUtil.LoadPath();

                if (strPath != "")
                {
                    m_cogTool_FindLineR.LoadConfig_Manual(strPath);
                }
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        private void metroButtonOCR_LoadJob_Click(object sender, EventArgs e)
        {
            try
            {
                string strPath = CUtil.LoadPath();

                if (strPath != "")
                {
                    if (m_cogTool_ViDi_OCR.LoadConfig_Manual(strPath) == true)
                    {
                        Global.iData.PropertyVisionInsp.MODEL_PATH = strPath;
                        propertyGrid_Spec.Refresh();
                    }

                }
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        private void metroButtonOCR_RUN_Click(object sender, EventArgs e)
        {
            
            List<double> dblScore = new List<double>();
            string strListBox = string.Empty;
            try
            {
                m_strOCRRead.Clear();
                listBoxOCR_Print.Items.Clear();
                if (m_cogTool_ViDi_OCR.RUN(m_ImageSource, out m_strOCRRead, out dblScore) == true)
                {
                    if (m_strOCRRead.Count == 0)
                    {
                        strListBox = "OCR 못찾음";
                        listBoxOCR_Print.Items.Add(strListBox);
                    }
                    //Global.iData.PropertyVisionInsp.MASTER_OCR = 
                    for (int i = 0; i < m_strOCRRead.Count; i++)
                    {
                        strListBox = $"{m_strOCRRead[i]} / {dblScore[i]:F3}%";
                        listBoxOCR_Print.Items.Add(strListBox);
                    }
                }
                else
                {
                    strListBox = "OCR 검색 실패";
                    listBoxOCR_Print.Items.Add(strListBox);
                }
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        private void metroButtonOCR_MASTER_Click(object sender, EventArgs e)
        {
            try
            {
                string str = string.Empty;
                for(int i = 0;i < m_strOCRRead.Count;i++)
                {
                    str = str + m_strOCRRead[i];
                }
                
                Global.iData.PropertyVisionInsp.MASTER_OCR = str;
                propertyGrid_Spec.Refresh();
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }

        private void metroButtonEjectCalcTime_Click(object sender, EventArgs e)
        {
            try
            {
                double dblSpeed = Global.iData.PropertyVisionInsp.EJECT_CONVEYOR_SPEED;// mm/s
                double dblDistanceFront = Global.iData.PropertyVisionInsp.EJECT_FRONT_DISTANCE;//mm
                double dblDistanceBack = Global.iData.PropertyVisionInsp.EJECT_BACK_DISTANCE;//mm
                double dblDistanceOCR = Global.iData.PropertyVisionInsp.EJECT_BOTTOM_DISTANCE;//mm

                dblSpeed = (dblSpeed == 0 ? 1 : dblSpeed);
                Global.iData.PropertyVisionInsp.EJECT_FRONT_TIME = (dblDistanceFront / dblSpeed);//s
                Global.iData.PropertyVisionInsp.EJECT_BACK_TIME = (dblDistanceBack / dblSpeed);
                Global.iData.PropertyVisionInsp.EJECT_BOTTOM_TIME = (dblDistanceOCR / dblSpeed);
                propertyGrid_Spec.Refresh();
            }
            catch (Exception ex)
            {
                CLogger.Add(LOG.EXCEPTION, "[FAILED] {0}==>{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, ex.Message);
            }
        }
    }
}