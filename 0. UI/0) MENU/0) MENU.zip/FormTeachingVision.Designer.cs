﻿namespace IntelligentFactory
{
    partial class FormTeachingVision
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

#region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormTeachingVision));
            this.metroStyleManager = new MetroFramework.Components.MetroStyleManager(this.components);
            this.metroLabel12 = new MetroFramework.Controls.MetroLabel();
            this.btnMeasureMean = new MetroFramework.Controls.MetroButton();
            this.lbThreshold = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.trbThreshold = new MetroFramework.Controls.MetroTrackBar();
            this.btnPatternRun = new MetroFramework.Controls.MetroButton();
            this.btnProperty_Pattern = new MetroFramework.Controls.MetroLabel();
            this.btnCameraOperator = new MetroFramework.Controls.MetroLabel();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.timerStatus = new System.Windows.Forms.Timer(this.components);
            this.metroLabel16 = new MetroFramework.Controls.MetroLabel();
            this.cbCamera = new MetroFramework.Controls.MetroComboBox();
            this.pnCameraOperator = new System.Windows.Forms.Panel();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.btnCameraImageSave = new MetroFramework.Controls.MetroButton();
            this.btnCameraImageLoad = new MetroFramework.Controls.MetroButton();
            this.btnCameraLive = new MetroFramework.Controls.MetroButton();
            this.btnCameraGrab = new MetroFramework.Controls.MetroButton();
            this.lbTackTimems = new System.Windows.Forms.Label();
            this.btnSaveVisionParam = new MetroFramework.Controls.MetroTile();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.lbMean = new System.Windows.Forms.Label();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.propertyGrid_Spec = new System.Windows.Forms.PropertyGrid();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.btnOpenEditTool = new MetroFramework.Controls.MetroButton();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.btnFindLineLeft = new MetroFramework.Controls.MetroButton();
            this.btnFindLineRight = new MetroFramework.Controls.MetroButton();
            this.btnPatternTrainRegion = new MetroFramework.Controls.MetroButton();
            this.btnPatternTrain = new MetroFramework.Controls.MetroButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cogDisplay_Source = new Cognex.VisionPro.Display.CogDisplay();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cogDisplay_Pattern = new Cognex.VisionPro.Display.CogDisplay();
            this.propertyGrid_Tool = new System.Windows.Forms.PropertyGrid();
            this.btnPatternSearchRegion = new MetroFramework.Controls.MetroButton();
            this.btnRunFindLineRight = new MetroFramework.Controls.MetroButton();
            this.btnRunFindLineLeft = new MetroFramework.Controls.MetroButton();
            this.btnInspectionAll = new MetroFramework.Controls.MetroButton();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.btnLoadConfig_PMAlign = new MetroFramework.Controls.MetroButton();
            this.btnLoadConfig_FindLineL = new MetroFramework.Controls.MetroButton();
            this.btnLoadConfig_FindLineR = new MetroFramework.Controls.MetroButton();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroButtonOCR_LoadJob = new MetroFramework.Controls.MetroButton();
            this.metroButtonOCR_RUN = new MetroFramework.Controls.MetroButton();
            this.lbResultRightLineToPatternDist = new System.Windows.Forms.Label();
            this.lbResultLeftLineToPatternDist = new System.Windows.Forms.Label();
            this.lbResultPatternAngle = new System.Windows.Forms.Label();
            this.lbResultPatternExist = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.listBoxOCR_Print = new System.Windows.Forms.ListBox();
            this.metroButtonOCR_MASTER = new MetroFramework.Controls.MetroButton();
            this.metroButtonEjectCalcTime = new MetroFramework.Controls.MetroButton();
            ((System.ComponentModel.ISupportInitialize)(this.metroStyleManager)).BeginInit();
            this.pnCameraOperator.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cogDisplay_Source)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cogDisplay_Pattern)).BeginInit();
            this.SuspendLayout();
            // 
            // metroStyleManager
            // 
            this.metroStyleManager.Owner = this;
            this.metroStyleManager.Style = MetroFramework.MetroColorStyle.Teal;
            // 
            // metroLabel12
            // 
            this.metroLabel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(170)))), ((int)(((byte)(173)))));
            this.metroLabel12.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel12.ForeColor = System.Drawing.Color.White;
            this.metroLabel12.Location = new System.Drawing.Point(1, 689);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(92, 35);
            this.metroLabel12.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroLabel12.TabIndex = 1433;
            this.metroLabel12.Text = "MEAN";
            this.metroLabel12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroLabel12.UseCustomBackColor = true;
            this.metroLabel12.UseCustomForeColor = true;
            // 
            // btnMeasureMean
            // 
            this.btnMeasureMean.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.btnMeasureMean.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btnMeasureMean.Highlight = true;
            this.btnMeasureMean.Location = new System.Drawing.Point(94, 689);
            this.btnMeasureMean.Name = "btnMeasureMean";
            this.btnMeasureMean.Size = new System.Drawing.Size(453, 35);
            this.btnMeasureMean.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnMeasureMean.TabIndex = 1432;
            this.btnMeasureMean.Text = "MEASURE";
            this.btnMeasureMean.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.btnMeasureMean.UseSelectable = true;
            this.btnMeasureMean.Click += new System.EventHandler(this.btnMeasureMean_Click);
            // 
            // lbThreshold
            // 
            this.lbThreshold.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(170)))), ((int)(((byte)(173)))));
            this.lbThreshold.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lbThreshold.ForeColor = System.Drawing.Color.White;
            this.lbThreshold.Location = new System.Drawing.Point(549, 653);
            this.lbThreshold.Name = "lbThreshold";
            this.lbThreshold.Size = new System.Drawing.Size(77, 35);
            this.lbThreshold.Style = MetroFramework.MetroColorStyle.Teal;
            this.lbThreshold.TabIndex = 1430;
            this.lbThreshold.Text = "000";
            this.lbThreshold.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbThreshold.UseCustomBackColor = true;
            this.lbThreshold.UseCustomForeColor = true;
            // 
            // metroLabel8
            // 
            this.metroLabel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(170)))), ((int)(((byte)(173)))));
            this.metroLabel8.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel8.ForeColor = System.Drawing.Color.White;
            this.metroLabel8.Location = new System.Drawing.Point(1, 653);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(92, 35);
            this.metroLabel8.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroLabel8.TabIndex = 1429;
            this.metroLabel8.Text = "Threshold";
            this.metroLabel8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroLabel8.UseCustomBackColor = true;
            this.metroLabel8.UseCustomForeColor = true;
            // 
            // trbThreshold
            // 
            this.trbThreshold.BackColor = System.Drawing.Color.Transparent;
            this.trbThreshold.Location = new System.Drawing.Point(94, 653);
            this.trbThreshold.Maximum = 254;
            this.trbThreshold.Minimum = 1;
            this.trbThreshold.Name = "trbThreshold";
            this.trbThreshold.Size = new System.Drawing.Size(453, 35);
            this.trbThreshold.TabIndex = 1428;
            this.trbThreshold.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.trbThreshold.Scroll += new System.Windows.Forms.ScrollEventHandler(this.trbThreshold_Scroll);
            // 
            // btnPatternRun
            // 
            this.btnPatternRun.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btnPatternRun.Highlight = true;
            this.btnPatternRun.Location = new System.Drawing.Point(976, 359);
            this.btnPatternRun.Name = "btnPatternRun";
            this.btnPatternRun.Size = new System.Drawing.Size(174, 39);
            this.btnPatternRun.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnPatternRun.TabIndex = 1222;
            this.btnPatternRun.Tag = "DEVICE";
            this.btnPatternRun.Text = "패턴 검사";
            this.btnPatternRun.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.btnPatternRun.UseSelectable = true;
            this.btnPatternRun.Click += new System.EventHandler(this.OnClickPatternRun);
            // 
            // btnProperty_Pattern
            // 
            this.btnProperty_Pattern.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(170)))), ((int)(((byte)(173)))));
            this.btnProperty_Pattern.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.btnProperty_Pattern.ForeColor = System.Drawing.Color.White;
            this.btnProperty_Pattern.Location = new System.Drawing.Point(627, 42);
            this.btnProperty_Pattern.Name = "btnProperty_Pattern";
            this.btnProperty_Pattern.Size = new System.Drawing.Size(521, 35);
            this.btnProperty_Pattern.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnProperty_Pattern.TabIndex = 1220;
            this.btnProperty_Pattern.Text = "패턴";
            this.btnProperty_Pattern.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnProperty_Pattern.UseCustomBackColor = true;
            this.btnProperty_Pattern.UseCustomForeColor = true;
            this.btnProperty_Pattern.Click += new System.EventHandler(this.OnClickMatchingProperty);
            // 
            // btnCameraOperator
            // 
            this.btnCameraOperator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(170)))), ((int)(((byte)(173)))));
            this.btnCameraOperator.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.btnCameraOperator.ForeColor = System.Drawing.Color.White;
            this.btnCameraOperator.Location = new System.Drawing.Point(0, 6);
            this.btnCameraOperator.Name = "btnCameraOperator";
            this.btnCameraOperator.Size = new System.Drawing.Size(491, 35);
            this.btnCameraOperator.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnCameraOperator.TabIndex = 1185;
            this.btnCameraOperator.Text = "VISION";
            this.btnCameraOperator.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnCameraOperator.UseCustomBackColor = true;
            this.btnCameraOperator.UseCustomForeColor = true;
            this.btnCameraOperator.Click += new System.EventHandler(this.btnCameraOperator_Click);
            // 
            // metroLabel9
            // 
            this.metroLabel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(170)))), ((int)(((byte)(173)))));
            this.metroLabel9.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel9.ForeColor = System.Drawing.Color.White;
            this.metroLabel9.Location = new System.Drawing.Point(627, 6);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(1132, 35);
            this.metroLabel9.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroLabel9.TabIndex = 1189;
            this.metroLabel9.Text = "PARAMETER";
            this.metroLabel9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroLabel9.UseCustomBackColor = true;
            this.metroLabel9.UseCustomForeColor = true;
            // 
            // timerStatus
            // 
            this.timerStatus.Enabled = true;
            this.timerStatus.Tick += new System.EventHandler(this.timerStatus_Tick);
            // 
            // metroLabel16
            // 
            this.metroLabel16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(170)))), ((int)(((byte)(173)))));
            this.metroLabel16.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel16.ForeColor = System.Drawing.Color.White;
            this.metroLabel16.Location = new System.Drawing.Point(1, 42);
            this.metroLabel16.Name = "metroLabel16";
            this.metroLabel16.Size = new System.Drawing.Size(135, 35);
            this.metroLabel16.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroLabel16.TabIndex = 1271;
            this.metroLabel16.Text = "NO";
            this.metroLabel16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroLabel16.UseCustomBackColor = true;
            this.metroLabel16.UseCustomForeColor = true;
            // 
            // cbCamera
            // 
            this.cbCamera.FontSize = MetroFramework.MetroComboBoxSize.Tall;
            this.cbCamera.FormattingEnabled = true;
            this.cbCamera.ItemHeight = 29;
            this.cbCamera.Items.AddRange(new object[] {
            "FRONT",
            "BACK",
            "OCR"});
            this.cbCamera.Location = new System.Drawing.Point(137, 42);
            this.cbCamera.Name = "cbCamera";
            this.cbCamera.Size = new System.Drawing.Size(489, 35);
            this.cbCamera.Style = MetroFramework.MetroColorStyle.Teal;
            this.cbCamera.TabIndex = 1270;
            this.cbCamera.Theme = MetroFramework.MetroThemeStyle.Light;
            this.cbCamera.UseSelectable = true;
            this.cbCamera.SelectedIndexChanged += new System.EventHandler(this.cbCamera_SelectedIndexChanged);
            // 
            // pnCameraOperator
            // 
            this.pnCameraOperator.Controls.Add(this.metroButton1);
            this.pnCameraOperator.Controls.Add(this.btnCameraImageSave);
            this.pnCameraOperator.Controls.Add(this.btnCameraImageLoad);
            this.pnCameraOperator.Controls.Add(this.btnCameraLive);
            this.pnCameraOperator.Controls.Add(this.btnCameraGrab);
            this.pnCameraOperator.Location = new System.Drawing.Point(2, 578);
            this.pnCameraOperator.Name = "pnCameraOperator";
            this.pnCameraOperator.Size = new System.Drawing.Size(624, 38);
            this.pnCameraOperator.TabIndex = 1725;
            // 
            // metroButton1
            // 
            this.metroButton1.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.metroButton1.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.metroButton1.Highlight = true;
            this.metroButton1.Location = new System.Drawing.Point(499, 1);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(123, 35);
            this.metroButton1.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroButton1.TabIndex = 1053;
            this.metroButton1.Text = "CROSS";
            this.metroButton1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton1.UseSelectable = true;
            this.metroButton1.Click += new System.EventHandler(this.OnClickCameraOperation);
            // 
            // btnCameraImageSave
            // 
            this.btnCameraImageSave.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btnCameraImageSave.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btnCameraImageSave.Highlight = true;
            this.btnCameraImageSave.Location = new System.Drawing.Point(375, 1);
            this.btnCameraImageSave.Name = "btnCameraImageSave";
            this.btnCameraImageSave.Size = new System.Drawing.Size(123, 35);
            this.btnCameraImageSave.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnCameraImageSave.TabIndex = 1052;
            this.btnCameraImageSave.Text = "IMAGE SAVE";
            this.btnCameraImageSave.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.btnCameraImageSave.UseSelectable = true;
            this.btnCameraImageSave.Click += new System.EventHandler(this.OnClickCameraOperation);
            // 
            // btnCameraImageLoad
            // 
            this.btnCameraImageLoad.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btnCameraImageLoad.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btnCameraImageLoad.Highlight = true;
            this.btnCameraImageLoad.Location = new System.Drawing.Point(249, 1);
            this.btnCameraImageLoad.Name = "btnCameraImageLoad";
            this.btnCameraImageLoad.Size = new System.Drawing.Size(125, 35);
            this.btnCameraImageLoad.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnCameraImageLoad.TabIndex = 1051;
            this.btnCameraImageLoad.Text = "IMAGE LOAD";
            this.btnCameraImageLoad.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.btnCameraImageLoad.UseSelectable = true;
            this.btnCameraImageLoad.Click += new System.EventHandler(this.OnClickCameraOperation);
            // 
            // btnCameraLive
            // 
            this.btnCameraLive.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btnCameraLive.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btnCameraLive.Highlight = true;
            this.btnCameraLive.Location = new System.Drawing.Point(125, 1);
            this.btnCameraLive.Name = "btnCameraLive";
            this.btnCameraLive.Size = new System.Drawing.Size(123, 35);
            this.btnCameraLive.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnCameraLive.TabIndex = 1050;
            this.btnCameraLive.Text = "LIVE";
            this.btnCameraLive.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.btnCameraLive.UseSelectable = true;
            this.btnCameraLive.Click += new System.EventHandler(this.OnClickCameraOperation);
            // 
            // btnCameraGrab
            // 
            this.btnCameraGrab.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btnCameraGrab.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.btnCameraGrab.Highlight = true;
            this.btnCameraGrab.Location = new System.Drawing.Point(-1, 1);
            this.btnCameraGrab.Name = "btnCameraGrab";
            this.btnCameraGrab.Size = new System.Drawing.Size(125, 35);
            this.btnCameraGrab.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnCameraGrab.TabIndex = 1049;
            this.btnCameraGrab.Text = "GRAB";
            this.btnCameraGrab.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.btnCameraGrab.UseSelectable = true;
            this.btnCameraGrab.Click += new System.EventHandler(this.OnClickCameraOperation);
            // 
            // lbTackTimems
            // 
            this.lbTackTimems.BackColor = System.Drawing.Color.Transparent;
            this.lbTackTimems.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTackTimems.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbTackTimems.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTackTimems.ForeColor = System.Drawing.Color.Black;
            this.lbTackTimems.Location = new System.Drawing.Point(492, 6);
            this.lbTackTimems.Name = "lbTackTimems";
            this.lbTackTimems.Size = new System.Drawing.Size(134, 35);
            this.lbTackTimems.TabIndex = 1731;
            this.lbTackTimems.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnSaveVisionParam
            // 
            this.btnSaveVisionParam.ActiveControl = null;
            this.btnSaveVisionParam.BackColor = System.Drawing.Color.Transparent;
            this.btnSaveVisionParam.Location = new System.Drawing.Point(627, 872);
            this.btnSaveVisionParam.Name = "btnSaveVisionParam";
            this.btnSaveVisionParam.Size = new System.Drawing.Size(1132, 58);
            this.btnSaveVisionParam.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnSaveVisionParam.TabIndex = 1740;
            this.btnSaveVisionParam.Text = "SAVE";
            this.btnSaveVisionParam.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSaveVisionParam.TileImage = global::IntelligentFactory.Properties.Resources.save_50;
            this.btnSaveVisionParam.TileImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSaveVisionParam.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.btnSaveVisionParam.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Bold;
            this.btnSaveVisionParam.UseSelectable = true;
            this.btnSaveVisionParam.UseTileImage = true;
            this.btnSaveVisionParam.Click += new System.EventHandler(this.btnSaveVisionParam_Click);
            // 
            // metroLabel4
            // 
            this.metroLabel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(170)))), ((int)(((byte)(173)))));
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel4.ForeColor = System.Drawing.Color.White;
            this.metroLabel4.Location = new System.Drawing.Point(1, 617);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(625, 35);
            this.metroLabel4.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroLabel4.TabIndex = 1744;
            this.metroLabel4.Text = "PROCESSING";
            this.metroLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroLabel4.UseCustomBackColor = true;
            this.metroLabel4.UseCustomForeColor = true;
            // 
            // lbMean
            // 
            this.lbMean.BackColor = System.Drawing.Color.Transparent;
            this.lbMean.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbMean.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbMean.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMean.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(170)))), ((int)(((byte)(173)))));
            this.lbMean.Location = new System.Drawing.Point(549, 689);
            this.lbMean.Name = "lbMean";
            this.lbMean.Size = new System.Drawing.Size(77, 37);
            this.lbMean.TabIndex = 1747;
            this.lbMean.Text = "00";
            this.lbMean.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // metroLabel6
            // 
            this.metroLabel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(170)))), ((int)(((byte)(173)))));
            this.metroLabel6.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel6.ForeColor = System.Drawing.Color.White;
            this.metroLabel6.Location = new System.Drawing.Point(1, 725);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(92, 57);
            this.metroLabel6.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroLabel6.TabIndex = 1757;
            this.metroLabel6.Text = "INSPECTION";
            this.metroLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroLabel6.UseCustomBackColor = true;
            this.metroLabel6.UseCustomForeColor = true;
            // 
            // propertyGrid_Spec
            // 
            this.propertyGrid_Spec.BackColor = System.Drawing.Color.Black;
            this.propertyGrid_Spec.CategoryForeColor = System.Drawing.Color.White;
            this.propertyGrid_Spec.CategorySplitterColor = System.Drawing.Color.Black;
            this.propertyGrid_Spec.CommandsBorderColor = System.Drawing.Color.Black;
            this.propertyGrid_Spec.CommandsDisabledLinkColor = System.Drawing.Color.White;
            this.propertyGrid_Spec.CommandsForeColor = System.Drawing.Color.White;
            this.propertyGrid_Spec.DisabledItemForeColor = System.Drawing.Color.White;
            this.propertyGrid_Spec.HelpBackColor = System.Drawing.Color.Black;
            this.propertyGrid_Spec.HelpBorderColor = System.Drawing.Color.Teal;
            this.propertyGrid_Spec.HelpForeColor = System.Drawing.Color.White;
            this.propertyGrid_Spec.HelpVisible = false;
            this.propertyGrid_Spec.LineColor = System.Drawing.Color.Teal;
            this.propertyGrid_Spec.Location = new System.Drawing.Point(1150, 437);
            this.propertyGrid_Spec.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.propertyGrid_Spec.Name = "propertyGrid_Spec";
            this.propertyGrid_Spec.PropertySort = System.Windows.Forms.PropertySort.Categorized;
            this.propertyGrid_Spec.SelectedItemWithFocusBackColor = System.Drawing.Color.Black;
            this.propertyGrid_Spec.SelectedItemWithFocusForeColor = System.Drawing.Color.Teal;
            this.propertyGrid_Spec.Size = new System.Drawing.Size(609, 434);
            this.propertyGrid_Spec.TabIndex = 1758;
            this.propertyGrid_Spec.ToolbarVisible = false;
            this.propertyGrid_Spec.ViewBackColor = System.Drawing.Color.Black;
            this.propertyGrid_Spec.ViewBorderColor = System.Drawing.Color.Teal;
            this.propertyGrid_Spec.ViewForeColor = System.Drawing.Color.White;
            // 
            // metroLabel5
            // 
            this.metroLabel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(170)))), ((int)(((byte)(173)))));
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel5.ForeColor = System.Drawing.Color.White;
            this.metroLabel5.Location = new System.Drawing.Point(1150, 401);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(609, 35);
            this.metroLabel5.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroLabel5.TabIndex = 1759;
            this.metroLabel5.Text = "검사 사양";
            this.metroLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroLabel5.UseCustomBackColor = true;
            this.metroLabel5.UseCustomForeColor = true;
            // 
            // btnOpenEditTool
            // 
            this.btnOpenEditTool.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btnOpenEditTool.Highlight = true;
            this.btnOpenEditTool.Location = new System.Drawing.Point(801, 359);
            this.btnOpenEditTool.Name = "btnOpenEditTool";
            this.btnOpenEditTool.Size = new System.Drawing.Size(174, 39);
            this.btnOpenEditTool.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnOpenEditTool.TabIndex = 1762;
            this.btnOpenEditTool.Tag = "OPEN EDIT TOOL";
            this.btnOpenEditTool.Text = "상세 티칭창 열기";
            this.btnOpenEditTool.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.btnOpenEditTool.UseSelectable = true;
            this.btnOpenEditTool.Click += new System.EventHandler(this.btnOpenEditTool_Click);
            // 
            // metroLabel1
            // 
            this.metroLabel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(170)))), ((int)(((byte)(173)))));
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel1.ForeColor = System.Drawing.Color.White;
            this.metroLabel1.Location = new System.Drawing.Point(1149, 42);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(610, 35);
            this.metroLabel1.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroLabel1.TabIndex = 1763;
            this.metroLabel1.Text = "에지 검출";
            this.metroLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroLabel1.UseCustomBackColor = true;
            this.metroLabel1.UseCustomForeColor = true;
            // 
            // btnFindLineLeft
            // 
            this.btnFindLineLeft.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btnFindLineLeft.Highlight = true;
            this.btnFindLineLeft.Location = new System.Drawing.Point(1149, 78);
            this.btnFindLineLeft.Name = "btnFindLineLeft";
            this.btnFindLineLeft.Size = new System.Drawing.Size(153, 42);
            this.btnFindLineLeft.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnFindLineLeft.TabIndex = 1764;
            this.btnFindLineLeft.Tag = "";
            this.btnFindLineLeft.Text = "세팅 (좌)";
            this.btnFindLineLeft.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.btnFindLineLeft.UseSelectable = true;
            this.btnFindLineLeft.Click += new System.EventHandler(this.btnFindLineLeft_Click);
            // 
            // btnFindLineRight
            // 
            this.btnFindLineRight.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btnFindLineRight.Highlight = true;
            this.btnFindLineRight.Location = new System.Drawing.Point(1457, 78);
            this.btnFindLineRight.Name = "btnFindLineRight";
            this.btnFindLineRight.Size = new System.Drawing.Size(151, 42);
            this.btnFindLineRight.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnFindLineRight.TabIndex = 1765;
            this.btnFindLineRight.Tag = "";
            this.btnFindLineRight.Text = "세팅 (우)";
            this.btnFindLineRight.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.btnFindLineRight.UseSelectable = true;
            this.btnFindLineRight.Click += new System.EventHandler(this.btnFindLineRight_Click);
            // 
            // btnPatternTrainRegion
            // 
            this.btnPatternTrainRegion.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btnPatternTrainRegion.Highlight = true;
            this.btnPatternTrainRegion.Location = new System.Drawing.Point(801, 319);
            this.btnPatternTrainRegion.Name = "btnPatternTrainRegion";
            this.btnPatternTrainRegion.Size = new System.Drawing.Size(174, 39);
            this.btnPatternTrainRegion.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnPatternTrainRegion.TabIndex = 1766;
            this.btnPatternTrainRegion.Tag = "";
            this.btnPatternTrainRegion.Text = "패턴 영역 설정";
            this.btnPatternTrainRegion.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.btnPatternTrainRegion.UseSelectable = true;
            this.btnPatternTrainRegion.Click += new System.EventHandler(this.btnPatternTrainRegion_Click);
            // 
            // btnPatternTrain
            // 
            this.btnPatternTrain.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btnPatternTrain.Highlight = true;
            this.btnPatternTrain.Location = new System.Drawing.Point(976, 319);
            this.btnPatternTrain.Name = "btnPatternTrain";
            this.btnPatternTrain.Size = new System.Drawing.Size(174, 39);
            this.btnPatternTrain.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnPatternTrain.TabIndex = 1767;
            this.btnPatternTrain.Tag = "";
            this.btnPatternTrain.Text = "패턴 영역 학습";
            this.btnPatternTrain.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.btnPatternTrain.UseSelectable = true;
            this.btnPatternTrain.Click += new System.EventHandler(this.btnPatternTrain_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.cogDisplay_Source);
            this.panel1.Location = new System.Drawing.Point(1, 78);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(625, 500);
            this.panel1.TabIndex = 1768;
            // 
            // cogDisplay_Source
            // 
            this.cogDisplay_Source.ColorMapLowerClipColor = System.Drawing.Color.Black;
            this.cogDisplay_Source.ColorMapLowerRoiLimit = 0D;
            this.cogDisplay_Source.ColorMapPredefined = Cognex.VisionPro.Display.CogDisplayColorMapPredefinedConstants.None;
            this.cogDisplay_Source.ColorMapUpperClipColor = System.Drawing.Color.Black;
            this.cogDisplay_Source.ColorMapUpperRoiLimit = 1D;
            this.cogDisplay_Source.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cogDisplay_Source.DoubleTapZoomCycleLength = 2;
            this.cogDisplay_Source.DoubleTapZoomSensitivity = 2.5D;
            this.cogDisplay_Source.Location = new System.Drawing.Point(0, 0);
            this.cogDisplay_Source.Margin = new System.Windows.Forms.Padding(4);
            this.cogDisplay_Source.MouseWheelMode = Cognex.VisionPro.Display.CogDisplayMouseWheelModeConstants.Zoom1;
            this.cogDisplay_Source.MouseWheelSensitivity = 1D;
            this.cogDisplay_Source.Name = "cogDisplay_Source";
            this.cogDisplay_Source.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("cogDisplay_Source.OcxState")));
            this.cogDisplay_Source.Size = new System.Drawing.Size(625, 500);
            this.cogDisplay_Source.TabIndex = 1761;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.cogDisplay_Pattern);
            this.panel2.Location = new System.Drawing.Point(627, 78);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(522, 238);
            this.panel2.TabIndex = 1769;
            // 
            // cogDisplay_Pattern
            // 
            this.cogDisplay_Pattern.ColorMapLowerClipColor = System.Drawing.Color.Black;
            this.cogDisplay_Pattern.ColorMapLowerRoiLimit = 0D;
            this.cogDisplay_Pattern.ColorMapPredefined = Cognex.VisionPro.Display.CogDisplayColorMapPredefinedConstants.None;
            this.cogDisplay_Pattern.ColorMapUpperClipColor = System.Drawing.Color.Black;
            this.cogDisplay_Pattern.ColorMapUpperRoiLimit = 1D;
            this.cogDisplay_Pattern.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cogDisplay_Pattern.DoubleTapZoomCycleLength = 2;
            this.cogDisplay_Pattern.DoubleTapZoomSensitivity = 2.5D;
            this.cogDisplay_Pattern.Location = new System.Drawing.Point(0, 0);
            this.cogDisplay_Pattern.Margin = new System.Windows.Forms.Padding(4);
            this.cogDisplay_Pattern.MouseWheelMode = Cognex.VisionPro.Display.CogDisplayMouseWheelModeConstants.Zoom1;
            this.cogDisplay_Pattern.MouseWheelSensitivity = 1D;
            this.cogDisplay_Pattern.Name = "cogDisplay_Pattern";
            this.cogDisplay_Pattern.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("cogDisplay_Pattern.OcxState")));
            this.cogDisplay_Pattern.Size = new System.Drawing.Size(522, 238);
            this.cogDisplay_Pattern.TabIndex = 1762;
            // 
            // propertyGrid_Tool
            // 
            this.propertyGrid_Tool.BackColor = System.Drawing.Color.Black;
            this.propertyGrid_Tool.CategoryForeColor = System.Drawing.Color.White;
            this.propertyGrid_Tool.CategorySplitterColor = System.Drawing.Color.Black;
            this.propertyGrid_Tool.CommandsBorderColor = System.Drawing.Color.Black;
            this.propertyGrid_Tool.CommandsDisabledLinkColor = System.Drawing.Color.White;
            this.propertyGrid_Tool.CommandsForeColor = System.Drawing.Color.White;
            this.propertyGrid_Tool.DisabledItemForeColor = System.Drawing.Color.White;
            this.propertyGrid_Tool.HelpBackColor = System.Drawing.Color.Black;
            this.propertyGrid_Tool.HelpBorderColor = System.Drawing.Color.Teal;
            this.propertyGrid_Tool.HelpForeColor = System.Drawing.Color.White;
            this.propertyGrid_Tool.HelpVisible = false;
            this.propertyGrid_Tool.LineColor = System.Drawing.Color.Teal;
            this.propertyGrid_Tool.Location = new System.Drawing.Point(626, 437);
            this.propertyGrid_Tool.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.propertyGrid_Tool.Name = "propertyGrid_Tool";
            this.propertyGrid_Tool.PropertySort = System.Windows.Forms.PropertySort.Categorized;
            this.propertyGrid_Tool.SelectedItemWithFocusBackColor = System.Drawing.Color.Black;
            this.propertyGrid_Tool.SelectedItemWithFocusForeColor = System.Drawing.Color.Teal;
            this.propertyGrid_Tool.Size = new System.Drawing.Size(524, 434);
            this.propertyGrid_Tool.TabIndex = 1770;
            this.propertyGrid_Tool.ToolbarVisible = false;
            this.propertyGrid_Tool.ViewBackColor = System.Drawing.Color.Black;
            this.propertyGrid_Tool.ViewBorderColor = System.Drawing.Color.Teal;
            this.propertyGrid_Tool.ViewForeColor = System.Drawing.Color.White;
            this.propertyGrid_Tool.PropertyValueChanged += new System.Windows.Forms.PropertyValueChangedEventHandler(this.propertyGrid_Tool_PropertyValueChanged);
            // 
            // btnPatternSearchRegion
            // 
            this.btnPatternSearchRegion.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btnPatternSearchRegion.Highlight = true;
            this.btnPatternSearchRegion.Location = new System.Drawing.Point(626, 319);
            this.btnPatternSearchRegion.Name = "btnPatternSearchRegion";
            this.btnPatternSearchRegion.Size = new System.Drawing.Size(174, 39);
            this.btnPatternSearchRegion.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnPatternSearchRegion.TabIndex = 1771;
            this.btnPatternSearchRegion.Tag = "";
            this.btnPatternSearchRegion.Text = "검사 영역 설정";
            this.btnPatternSearchRegion.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.btnPatternSearchRegion.UseSelectable = true;
            this.btnPatternSearchRegion.Click += new System.EventHandler(this.btnPatternSearchRegion_Click);
            // 
            // btnRunFindLineRight
            // 
            this.btnRunFindLineRight.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btnRunFindLineRight.Highlight = true;
            this.btnRunFindLineRight.Location = new System.Drawing.Point(1609, 78);
            this.btnRunFindLineRight.Name = "btnRunFindLineRight";
            this.btnRunFindLineRight.Size = new System.Drawing.Size(151, 42);
            this.btnRunFindLineRight.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnRunFindLineRight.TabIndex = 1773;
            this.btnRunFindLineRight.Tag = "";
            this.btnRunFindLineRight.Text = "검사 (우)";
            this.btnRunFindLineRight.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.btnRunFindLineRight.UseSelectable = true;
            this.btnRunFindLineRight.Click += new System.EventHandler(this.btnRunFindLineRight_Click);
            // 
            // btnRunFindLineLeft
            // 
            this.btnRunFindLineLeft.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btnRunFindLineLeft.Highlight = true;
            this.btnRunFindLineLeft.Location = new System.Drawing.Point(1303, 78);
            this.btnRunFindLineLeft.Name = "btnRunFindLineLeft";
            this.btnRunFindLineLeft.Size = new System.Drawing.Size(153, 42);
            this.btnRunFindLineLeft.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnRunFindLineLeft.TabIndex = 1772;
            this.btnRunFindLineLeft.Tag = "";
            this.btnRunFindLineLeft.Text = "검사 (좌)";
            this.btnRunFindLineLeft.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.btnRunFindLineLeft.UseSelectable = true;
            this.btnRunFindLineLeft.Click += new System.EventHandler(this.btnRunFindLineLeft_Click);
            // 
            // btnInspectionAll
            // 
            this.btnInspectionAll.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btnInspectionAll.Highlight = true;
            this.btnInspectionAll.Location = new System.Drawing.Point(94, 725);
            this.btnInspectionAll.Name = "btnInspectionAll";
            this.btnInspectionAll.Size = new System.Drawing.Size(532, 57);
            this.btnInspectionAll.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnInspectionAll.TabIndex = 1774;
            this.btnInspectionAll.Tag = "";
            this.btnInspectionAll.Text = "전체 검사";
            this.btnInspectionAll.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.btnInspectionAll.UseSelectable = true;
            this.btnInspectionAll.Click += new System.EventHandler(this.btnInspectionAll_Click);
            // 
            // metroLabel2
            // 
            this.metroLabel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(170)))), ((int)(((byte)(173)))));
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel2.ForeColor = System.Drawing.Color.White;
            this.metroLabel2.Location = new System.Drawing.Point(1150, 161);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(610, 35);
            this.metroLabel2.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroLabel2.TabIndex = 1775;
            this.metroLabel2.Text = "OCR";
            this.metroLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroLabel2.UseCustomBackColor = true;
            this.metroLabel2.UseCustomForeColor = true;
            // 
            // btnLoadConfig_PMAlign
            // 
            this.btnLoadConfig_PMAlign.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btnLoadConfig_PMAlign.Highlight = true;
            this.btnLoadConfig_PMAlign.Location = new System.Drawing.Point(626, 359);
            this.btnLoadConfig_PMAlign.Name = "btnLoadConfig_PMAlign";
            this.btnLoadConfig_PMAlign.Size = new System.Drawing.Size(174, 39);
            this.btnLoadConfig_PMAlign.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnLoadConfig_PMAlign.TabIndex = 1776;
            this.btnLoadConfig_PMAlign.Tag = "OPEN EDIT TOOL";
            this.btnLoadConfig_PMAlign.Text = "JOB 불러오기";
            this.btnLoadConfig_PMAlign.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.btnLoadConfig_PMAlign.UseSelectable = true;
            this.btnLoadConfig_PMAlign.Click += new System.EventHandler(this.btnLoadConfig_PMAlign_Click);
            // 
            // btnLoadConfig_FindLineL
            // 
            this.btnLoadConfig_FindLineL.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btnLoadConfig_FindLineL.Highlight = true;
            this.btnLoadConfig_FindLineL.Location = new System.Drawing.Point(1149, 121);
            this.btnLoadConfig_FindLineL.Name = "btnLoadConfig_FindLineL";
            this.btnLoadConfig_FindLineL.Size = new System.Drawing.Size(307, 39);
            this.btnLoadConfig_FindLineL.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnLoadConfig_FindLineL.TabIndex = 1777;
            this.btnLoadConfig_FindLineL.Tag = "OPEN EDIT TOOL";
            this.btnLoadConfig_FindLineL.Text = "JOB 불러오기 (좌)";
            this.btnLoadConfig_FindLineL.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.btnLoadConfig_FindLineL.UseSelectable = true;
            this.btnLoadConfig_FindLineL.Click += new System.EventHandler(this.btnLoadConfig_FindLineL_Click);
            // 
            // btnLoadConfig_FindLineR
            // 
            this.btnLoadConfig_FindLineR.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.btnLoadConfig_FindLineR.Highlight = true;
            this.btnLoadConfig_FindLineR.Location = new System.Drawing.Point(1457, 121);
            this.btnLoadConfig_FindLineR.Name = "btnLoadConfig_FindLineR";
            this.btnLoadConfig_FindLineR.Size = new System.Drawing.Size(303, 39);
            this.btnLoadConfig_FindLineR.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnLoadConfig_FindLineR.TabIndex = 1778;
            this.btnLoadConfig_FindLineR.Tag = "OPEN EDIT TOOL";
            this.btnLoadConfig_FindLineR.Text = "JOB 불러오기 (우)";
            this.btnLoadConfig_FindLineR.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.btnLoadConfig_FindLineR.UseSelectable = true;
            this.btnLoadConfig_FindLineR.Click += new System.EventHandler(this.btnLoadConfig_FindLineR_Click);
            // 
            // metroLabel3
            // 
            this.metroLabel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(170)))), ((int)(((byte)(173)))));
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel3.ForeColor = System.Drawing.Color.White;
            this.metroLabel3.Location = new System.Drawing.Point(626, 401);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(523, 35);
            this.metroLabel3.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroLabel3.TabIndex = 1779;
            this.metroLabel3.Text = "툴 정보";
            this.metroLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroLabel3.UseCustomBackColor = true;
            this.metroLabel3.UseCustomForeColor = true;
            // 
            // metroButtonOCR_LoadJob
            // 
            this.metroButtonOCR_LoadJob.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.metroButtonOCR_LoadJob.Highlight = true;
            this.metroButtonOCR_LoadJob.Location = new System.Drawing.Point(1150, 197);
            this.metroButtonOCR_LoadJob.Name = "metroButtonOCR_LoadJob";
            this.metroButtonOCR_LoadJob.Size = new System.Drawing.Size(307, 39);
            this.metroButtonOCR_LoadJob.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroButtonOCR_LoadJob.TabIndex = 1780;
            this.metroButtonOCR_LoadJob.Tag = "OPEN EDIT TOOL";
            this.metroButtonOCR_LoadJob.Text = "JOB 불러오기";
            this.metroButtonOCR_LoadJob.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButtonOCR_LoadJob.UseSelectable = true;
            this.metroButtonOCR_LoadJob.Click += new System.EventHandler(this.metroButtonOCR_LoadJob_Click);
            // 
            // metroButtonOCR_RUN
            // 
            this.metroButtonOCR_RUN.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.metroButtonOCR_RUN.Highlight = true;
            this.metroButtonOCR_RUN.Location = new System.Drawing.Point(1150, 242);
            this.metroButtonOCR_RUN.Name = "metroButtonOCR_RUN";
            this.metroButtonOCR_RUN.Size = new System.Drawing.Size(307, 39);
            this.metroButtonOCR_RUN.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroButtonOCR_RUN.TabIndex = 1781;
            this.metroButtonOCR_RUN.Tag = "OPEN EDIT TOOL";
            this.metroButtonOCR_RUN.Text = "OCR 검사";
            this.metroButtonOCR_RUN.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButtonOCR_RUN.UseSelectable = true;
            this.metroButtonOCR_RUN.Click += new System.EventHandler(this.metroButtonOCR_RUN_Click);
            // 
            // lbResultRightLineToPatternDist
            // 
            this.lbResultRightLineToPatternDist.BackColor = System.Drawing.Color.Transparent;
            this.lbResultRightLineToPatternDist.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbResultRightLineToPatternDist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbResultRightLineToPatternDist.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbResultRightLineToPatternDist.ForeColor = System.Drawing.Color.Black;
            this.lbResultRightLineToPatternDist.Location = new System.Drawing.Point(325, 894);
            this.lbResultRightLineToPatternDist.Name = "lbResultRightLineToPatternDist";
            this.lbResultRightLineToPatternDist.Size = new System.Drawing.Size(301, 36);
            this.lbResultRightLineToPatternDist.TabIndex = 1833;
            this.lbResultRightLineToPatternDist.Text = "00.00 mm";
            this.lbResultRightLineToPatternDist.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbResultLeftLineToPatternDist
            // 
            this.lbResultLeftLineToPatternDist.BackColor = System.Drawing.Color.Transparent;
            this.lbResultLeftLineToPatternDist.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbResultLeftLineToPatternDist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbResultLeftLineToPatternDist.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbResultLeftLineToPatternDist.ForeColor = System.Drawing.Color.Black;
            this.lbResultLeftLineToPatternDist.Location = new System.Drawing.Point(325, 857);
            this.lbResultLeftLineToPatternDist.Name = "lbResultLeftLineToPatternDist";
            this.lbResultLeftLineToPatternDist.Size = new System.Drawing.Size(301, 36);
            this.lbResultLeftLineToPatternDist.TabIndex = 1832;
            this.lbResultLeftLineToPatternDist.Text = "00.00 mm";
            this.lbResultLeftLineToPatternDist.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbResultPatternAngle
            // 
            this.lbResultPatternAngle.BackColor = System.Drawing.Color.Transparent;
            this.lbResultPatternAngle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbResultPatternAngle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbResultPatternAngle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbResultPatternAngle.ForeColor = System.Drawing.Color.Black;
            this.lbResultPatternAngle.Location = new System.Drawing.Point(325, 820);
            this.lbResultPatternAngle.Name = "lbResultPatternAngle";
            this.lbResultPatternAngle.Size = new System.Drawing.Size(301, 36);
            this.lbResultPatternAngle.TabIndex = 1831;
            this.lbResultPatternAngle.Text = "00.00º";
            this.lbResultPatternAngle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbResultPatternExist
            // 
            this.lbResultPatternExist.BackColor = System.Drawing.Color.Transparent;
            this.lbResultPatternExist.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbResultPatternExist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbResultPatternExist.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbResultPatternExist.ForeColor = System.Drawing.Color.Black;
            this.lbResultPatternExist.Location = new System.Drawing.Point(325, 783);
            this.lbResultPatternExist.Name = "lbResultPatternExist";
            this.lbResultPatternExist.Size = new System.Drawing.Size(301, 36);
            this.lbResultPatternExist.TabIndex = 1830;
            this.lbResultPatternExist.Text = "READY";
            this.lbResultPatternExist.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(170)))), ((int)(((byte)(173)))));
            this.label14.Location = new System.Drawing.Point(121, 783);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(203, 36);
            this.label14.TabIndex = 1829;
            this.label14.Text = "패턴 유무";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(170)))), ((int)(((byte)(173)))));
            this.label17.Location = new System.Drawing.Point(121, 820);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(203, 36);
            this.label17.TabIndex = 1828;
            this.label17.Text = "패턴 각도";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(170)))), ((int)(((byte)(173)))));
            this.label18.Location = new System.Drawing.Point(121, 894);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(203, 36);
            this.label18.TabIndex = 1827;
            this.label18.Text = "에지(우) - 패턴 거리 (mm)";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(170)))), ((int)(((byte)(173)))));
            this.label24.Location = new System.Drawing.Point(121, 857);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(203, 36);
            this.label24.TabIndex = 1826;
            this.label24.Text = "에지(좌) - 패턴 거리 (mm)";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.Color.Transparent;
            this.label25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold);
            this.label25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(170)))), ((int)(((byte)(173)))));
            this.label25.Location = new System.Drawing.Point(0, 783);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(120, 147);
            this.label25.TabIndex = 1825;
            this.label25.Text = "결과";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // listBoxOCR_Print
            // 
            this.listBoxOCR_Print.FormattingEnabled = true;
            this.listBoxOCR_Print.ItemHeight = 12;
            this.listBoxOCR_Print.Location = new System.Drawing.Point(1463, 206);
            this.listBoxOCR_Print.Name = "listBoxOCR_Print";
            this.listBoxOCR_Print.Size = new System.Drawing.Size(296, 184);
            this.listBoxOCR_Print.TabIndex = 1834;
            // 
            // metroButtonOCR_MASTER
            // 
            this.metroButtonOCR_MASTER.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.metroButtonOCR_MASTER.Highlight = true;
            this.metroButtonOCR_MASTER.Location = new System.Drawing.Point(1149, 287);
            this.metroButtonOCR_MASTER.Name = "metroButtonOCR_MASTER";
            this.metroButtonOCR_MASTER.Size = new System.Drawing.Size(307, 39);
            this.metroButtonOCR_MASTER.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroButtonOCR_MASTER.TabIndex = 1835;
            this.metroButtonOCR_MASTER.Tag = "OPEN EDIT TOOL";
            this.metroButtonOCR_MASTER.Text = "MASTER OCR";
            this.metroButtonOCR_MASTER.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButtonOCR_MASTER.UseSelectable = true;
            this.metroButtonOCR_MASTER.Click += new System.EventHandler(this.metroButtonOCR_MASTER_Click);
            // 
            // metroButtonEjectCalcTime
            // 
            this.metroButtonEjectCalcTime.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.metroButtonEjectCalcTime.Highlight = true;
            this.metroButtonEjectCalcTime.Location = new System.Drawing.Point(1150, 359);
            this.metroButtonEjectCalcTime.Name = "metroButtonEjectCalcTime";
            this.metroButtonEjectCalcTime.Size = new System.Drawing.Size(307, 39);
            this.metroButtonEjectCalcTime.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroButtonEjectCalcTime.TabIndex = 1836;
            this.metroButtonEjectCalcTime.Tag = "OPEN EDIT TOOL";
            this.metroButtonEjectCalcTime.Text = "EJECT 도달 시간 계산";
            this.metroButtonEjectCalcTime.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButtonEjectCalcTime.UseSelectable = true;
            this.metroButtonEjectCalcTime.Click += new System.EventHandler(this.metroButtonEjectCalcTime_Click);
            // 
            // FormTeachingVision
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1760, 930);
            this.ControlBox = false;
            this.Controls.Add(this.metroButtonEjectCalcTime);
            this.Controls.Add(this.metroButtonOCR_MASTER);
            this.Controls.Add(this.listBoxOCR_Print);
            this.Controls.Add(this.lbResultRightLineToPatternDist);
            this.Controls.Add(this.lbResultLeftLineToPatternDist);
            this.Controls.Add(this.lbResultPatternAngle);
            this.Controls.Add(this.lbResultPatternExist);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.metroButtonOCR_RUN);
            this.Controls.Add(this.metroButtonOCR_LoadJob);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.btnLoadConfig_FindLineR);
            this.Controls.Add(this.btnLoadConfig_FindLineL);
            this.Controls.Add(this.btnLoadConfig_PMAlign);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.btnInspectionAll);
            this.Controls.Add(this.btnRunFindLineRight);
            this.Controls.Add(this.btnRunFindLineLeft);
            this.Controls.Add(this.btnPatternSearchRegion);
            this.Controls.Add(this.propertyGrid_Tool);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnPatternTrain);
            this.Controls.Add(this.btnPatternTrainRegion);
            this.Controls.Add(this.btnFindLineRight);
            this.Controls.Add(this.btnFindLineLeft);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.btnOpenEditTool);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.propertyGrid_Spec);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.lbMean);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.metroLabel12);
            this.Controls.Add(this.btnMeasureMean);
            this.Controls.Add(this.btnPatternRun);
            this.Controls.Add(this.lbThreshold);
            this.Controls.Add(this.metroLabel8);
            this.Controls.Add(this.trbThreshold);
            this.Controls.Add(this.lbTackTimems);
            this.Controls.Add(this.btnProperty_Pattern);
            this.Controls.Add(this.pnCameraOperator);
            this.Controls.Add(this.metroLabel16);
            this.Controls.Add(this.cbCamera);
            this.Controls.Add(this.metroLabel9);
            this.Controls.Add(this.btnCameraOperator);
            this.Controls.Add(this.btnSaveVisionParam);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Movable = false;
            this.Name = "FormTeachingVision";
            this.Resizable = false;
            this.ShadowType = MetroFramework.Forms.MetroFormShadowType.None;
            this.ShowInTaskbar = false;
            this.Style = MetroFramework.MetroColorStyle.Teal;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormTeachingMotion_FormClosing);
            this.Load += new System.EventHandler(this.FormTeachingVision_Load);
            ((System.ComponentModel.ISupportInitialize)(this.metroStyleManager)).EndInit();
            this.pnCameraOperator.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cogDisplay_Source)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cogDisplay_Pattern)).EndInit();
            this.ResumeLayout(false);

        }

#endregion

        private MetroFramework.Components.MetroStyleManager metroStyleManager;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroLabel btnCameraOperator;
        private System.Windows.Forms.Timer timerStatus;
        private MetroFramework.Controls.MetroLabel metroLabel16;
        private MetroFramework.Controls.MetroComboBox cbCamera;
        private System.Windows.Forms.Panel pnCameraOperator;
        private MetroFramework.Controls.MetroButton btnCameraImageSave;
        private MetroFramework.Controls.MetroButton btnCameraImageLoad;
        private MetroFramework.Controls.MetroButton btnCameraLive;
        private MetroFramework.Controls.MetroButton btnCameraGrab;
        private MetroFramework.Controls.MetroButton metroButton1;
        private MetroFramework.Controls.MetroLabel lbThreshold;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroTrackBar trbThreshold;
        private MetroFramework.Controls.MetroButton btnPatternRun;
        private MetroFramework.Controls.MetroLabel btnProperty_Pattern;
        private MetroFramework.Controls.MetroLabel metroLabel12;
        private MetroFramework.Controls.MetroButton btnMeasureMean;
        private System.Windows.Forms.Label lbTackTimems;
        private MetroFramework.Controls.MetroTile btnSaveVisionParam;
        private System.Windows.Forms.Label lbMean;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private System.Windows.Forms.PropertyGrid propertyGrid_Spec;
        private MetroFramework.Controls.MetroButton btnFindLineRight;
        private MetroFramework.Controls.MetroButton btnFindLineLeft;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroButton btnOpenEditTool;
        private MetroFramework.Controls.MetroButton btnPatternTrainRegion;
        private MetroFramework.Controls.MetroButton btnPatternTrain;
        private System.Windows.Forms.Panel panel2;
        internal Cognex.VisionPro.Display.CogDisplay cogDisplay_Pattern;
        private System.Windows.Forms.Panel panel1;
        internal Cognex.VisionPro.Display.CogDisplay cogDisplay_Source;
        private System.Windows.Forms.PropertyGrid propertyGrid_Tool;
        private MetroFramework.Controls.MetroButton btnPatternSearchRegion;
        private MetroFramework.Controls.MetroButton btnInspectionAll;
        private MetroFramework.Controls.MetroButton btnRunFindLineRight;
        private MetroFramework.Controls.MetroButton btnRunFindLineLeft;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroButton btnLoadConfig_FindLineR;
        private MetroFramework.Controls.MetroButton btnLoadConfig_FindLineL;
        private MetroFramework.Controls.MetroButton btnLoadConfig_PMAlign;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroButton metroButtonOCR_RUN;
        private MetroFramework.Controls.MetroButton metroButtonOCR_LoadJob;
        private System.Windows.Forms.Label lbResultRightLineToPatternDist;
        private System.Windows.Forms.Label lbResultLeftLineToPatternDist;
        private System.Windows.Forms.Label lbResultPatternAngle;
        private System.Windows.Forms.Label lbResultPatternExist;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ListBox listBoxOCR_Print;
        private MetroFramework.Controls.MetroButton metroButtonOCR_MASTER;
        private MetroFramework.Controls.MetroButton metroButtonEjectCalcTime;
    }
}
